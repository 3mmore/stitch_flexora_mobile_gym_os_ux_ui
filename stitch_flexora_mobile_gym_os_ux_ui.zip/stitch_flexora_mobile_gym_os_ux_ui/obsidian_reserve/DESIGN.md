---
name: Obsidian Reserve
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1b1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#e9c176'
  on-secondary: '#412d00'
  secondary-container: '#604403'
  on-secondary-container: '#dab36a'
  tertiary: '#cfcdd8'
  on-tertiary: '#303038'
  tertiary-container: '#b4b2bc'
  on-tertiary-container: '#45444d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e4e1ec'
  tertiary-fixed-dim: '#c7c5d0'
  on-tertiary-fixed: '#1b1b22'
  on-tertiary-fixed-variant: '#46464f'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-xl-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  title-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  numeric-metric:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system expresses a luxury fitness operating system where high-performance SaaS rigor converges with the quiet authority of private wealth banking. Designed Arabic-first with native Right-to-Left (RTL) ergonomics, the interface communicates institutional stability, bespoke hospitality, and tactical operational control for boutique fitness operators and premium members.

The visual style blends **Modern Tactical Minimalism** with **Warm Bespoke Luxury**:
- **Tactile Fineness:** Surfaces resemble anodized brushed carbon, matte stone, and fine-grain Horween leather rather than generic digital slate.
- **Controlled Warmth:** Elimination of pure blue-spectrum darks in favor of deep basalt and molten charcoal, creating visual depth without eye fatigue.
- **Precision Restraint:** Gold and bronze elements are preserved strictly as intentional focal points, status markers, and affirmative micro-actions—never decorative clutter.
- **Boutique Architecture:** Generous vertical rhythm, architectural line dividers, and high-legibility numerals engineered for both dimly lit club floors and high-noon outdoor mobility.

## Colors

The palette employs deep basalt foundations with layered charcoal densities and calculated metallic illumination.

### Palette Architecture
- **Canvas Base (`#0E0E10`):** Obsidian black canvas with a microscopic warm undertone, preventing the clinical sterile quality of absolute OLED `#000000`.
- **Card Surfaces (`#16161A`, `#1C1C22`):** Primary and secondary container tiers that create architectural depth through low-contrast elevation rather than cast shadows.
- **Structural Outlines (`#2A2A32`):** Hairline precision borders separating modular telemetry and layout cards.
- **Metallic Hierarchy:**
  - **Refined Gold (`#D4AF37`):** Reserved for active interaction triggers, primary CTAs, VIP tier badges, and key financial summaries.
  - **Muted Bronze (`#C5A059`):** Used for auxiliary state highlights, focused tab bars, and secondary financial metrics.
- **Typography & Content:**
  - **Dominant Primary (`#F4F4F6`):** Soft, warm off-white delivering uncompromised contrast without the harsh retina glare of pure `#FFFFFF`.
  - **Secondary Neutral (`#9E9EA8`):** Muted mineral gray engineered to pass WCAG AA standards against all charcoal card variations for secondary telemetry, timestamps, and contextual captions.
  - **Operational Status:** Emerald (`#2E7D5B`) for active memberships/capacity health, Crimson (`#C34A4A`) for overdue accounts/access lock, and Amber (`#C58A3E`) for maintenance/waitlists.

## Typography

Typography relies on **IBM Plex Sans** (with fallback to native Arabic glyph sets via IBM Plex Sans Arabic) to project architectural precision and clear reading comfort.

### RTL Script Considerations
- **Baseline Alignment:** Arabic scripts inherently require higher ascender and descender clearances. Line-height tokens are calibrated with a 4px expansion relative to Latin-centric baselines to completely eliminate clipping of complex ligatures and tashkeel.
- **Typographic Weights:** Arabic typography maintains perceived parity with Latin when weights are moderated: headlines employ `600` (SemiBold) rather than `700`+ (Bold), preserving legibility in complex glyph counters.
- **Directional Dynamics:** Numerical data (revenue, check-ins, sets, repetitions) can be displayed in Western Arabic numerals (`0-9`) or Eastern Arabic numerals (`٠-٩`) based on club locale settings, while preserving monospace tabular alignment for scanning accounting columns.

## Layout & Spacing

The layout is built around an RTL-first mobile viewport structure with an ergonomic 4px/8px modular cadence.

### Layout Mechanics
- **Mobile First Canvas:** Optimized for standard viewport widths (390px-430px) with single-hand reach zones. Critical action surfaces nestle in the lower third of the canvas.
- **RTL Fluidity:** Grid margins anchor from the right edge. Primary progression movements travel from right to left: forward navigation pushes right-to-left, backward retreat pops left-to-right.
- **Horizontal Scrolling Shelves:** Member carousels, schedule timelines, and live capacity tracks use edge-to-edge overflow with an inner padding offset matching canvas margins (`1rem`), snapping cleanly to column boundaries.
- **Safe Area Insets:** Fixed bottom navigational elements enforce dynamic platform bottom safe area handling (`env(safe-area-inset-bottom) + 8px`) ensuring effortless touch registration.

## Elevation & Depth

This system avoids floating drop shadows, which dilute the grounded, physical character of luxury dark UIs. Instead, depth is conveyed through **Tonal Layering with Muted Perimeter Borders**.

- **Canvas Foundation (`#0E0E10`):** Ground level. Application shell, navigation backdrops, and root structural margins.
- **Surface Level 1 (`#16161A`):** Large dashboard groupings, full-width schedule containers, and primary data modules. Outlined with a continuous 1px `#2A2A32` border.
- **Surface Level 2 (`#1C1C22`):** Interactive nested tiles, form input fields, segmented control backdrops, and active roster cards. Outlined with 1px `#2A2A32`.
- **Surface Level 3 - Overlay Layer (`#22222A`):** Modals, action sheets, and drawer pullouts. Accompanied by a deep ambient diffusion: `0 16px 40px -8px rgba(0, 0, 0, 0.7)` and a perimeter hairline border tinted with 12% gold (`rgba(212, 175, 55, 0.12)`).
- **Hairline Geometry:** Every container boundary utilizes a razor-sharp 1px border. Under no circumstances should soft, heavy, multi-directional colored drop shadows be introduced.

## Shapes

The geometric framework balances executive discipline with approachable mobile handling.

- **Base Radius (Roundedness `2` - `0.5rem` / `8px`):** Applied to standard interactive targets including text fields, secondary buttons, badge indicators, and list row highlights.
- **Container Radius (`rounded-lg` - `1rem` / `16px`):** Applied to primary cards, telemetry tiles, and member profile panels.
- **Overlay Radius (`rounded-xl` - `1.5rem` / `24px`):** Applied strictly to the top leading/trailing corners of sliding modal sheets and interactive drawer panels.
- **Pill Radius (Full `9999px`):** Reserved exclusively for status chips, filter pills, biometric access tags, and quick-action floaters.

## Components

### Buttons
- **Primary Action:** Solid metallic gradient or high-luster fill (`#D4AF37`) with ink text (`#0E0E10`, SemiBold 14px). Minimum height 48px to accommodate ergonomic thumb engagement. Pressed state darkens to `#C5A059`.
- **Secondary Action:** Charcoal base (`#1C1C22`) with hairline border (`#2A2A32`) and warm white label (`#F4F4F6`). Active state shifts border to 40% primary gold.
- **Ghost Action:** Pure text button in `#C5A059`, no background, 8px horizontal padding.
- **Icon Alignment (RTL):** Trailing accessory icons (forward arrows, confirmations) appear on the left in RTL orientation.

### Bottom Navigation Bar
- **Architecture:** Compact Facebook-style simplicity with a locked 5-tab layout: Overview (نظرة عامة), Roster/Members (الأعضاء), Schedule (الجدول), Financials (المالية), and Profile/Operations (الإدارة).
- **Surface:** `#0E0E10` base at 92% opacity with iOS/Android native background blur (backdrop-filter: blur(20px)).
- **Top Border:** 1px solid `#2A2A32`.
- **States:** Active tab displays crisp 1.75px stroke Lucide-style gold icon (`#D4AF37`) with a 4px circular glow pip beneath. Inactive tabs display muted gray icons (`#9E9EA8`) with no text label on condensed screens to maximize horizontal spacing.

### Cards & Telemetry Tiles
- **Structure:** `#16161A` fill encased in 1px `#2A2A32`. Padding locked to 16px.
- **Metric Header:** 12px muted label (`#9E9EA8`) aligned right, accompanied by an optional left-aligned trend pill (e.g., `+14.2%` in `#2E7D5B`).
- **Core Value:** 28px SemiBold metric in `#F4F4F6` with localized currency symbol or capacity sign.

### Input Fields
- **Container:** `#1C1C22` background, 1px `#2A2A32` border, 48px height, 12px horizontal padding.
- **Text Alignment:** Right-aligned placeholder and input text (`#9E9EA8` placeholder, `#F4F4F6` input).
- **Focus State:** Border transitions cleanly to `#D4AF37` with an ultra-subtle outer ring: `0 0 0 1px #D4AF37`.

### Selection Controls (Radio & Checkbox)
- **Checkbox:** 20px square with 4px border radius. Unchecked: `#16161A` with `#2A2A32` border. Checked: `#D4AF37` fill with dark checkmark glyph (`#0E0E10`).
- **Radio:** 20px concentric circle. Checked state features a 8px centered solid `#D4AF37` bullseye inside a `#16161A` base ring.
- **Alignment:** Anchored to the right edge of list rows in RTL.

### Chips & Status Tags
- **Structure:** Pill-shaped (height 28px), 10px lateral padding.
- **VIP / Premium Status:** Gold outline tier with deep amber background tint (`rgba(212, 175, 55, 0.1)`), text rendered in `#D4AF37`.
- **System States:** Live Capacity, Inactive, and Maintenance use 10% opacity tints of their respective semantic colors with matching 1px semi-opaque borders.

### Member & Trainer Lists
- **Row Configuration:** 64px row height on `#16161A` background separated by hairline dividers (`#2A2A32`).
- **RTL Ordering:** Right side hosts the avatar (40px circle or squircle with `#2A2A32` border). Center holds the primary name (`#F4F4F6`, 14px SemiBold) stacked over status/membership rank (`#9E9EA8`, 12px). Left side holds the contextual action trigger or disclosure chevron pointing leftward (`ChevronLeft`).